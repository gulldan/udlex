# Licence

Everything in this release — the word list, the per-source counts, the lexicon, the glosses, the
code and the documentation — is dedicated to the public domain under
**CC0 1.0** ([legal code](https://creativecommons.org/publicdomain/zero/1.0/legalcode)).
Use it for anything, with or without credit.

## Why that is possible

The release contains no text from its sources: only word counts and statistics computed from them,
plus a lexicon, glosses and code written for this project. Creative Commons' own guidance is that
its licences permit text and data mining and that the results of an analysis are not an adaptation
of the material analysed ([Creative Commons: content mining](https://wiki.creativecommons.org/wiki/Content_mining)).
The sources themselves are not redistributed; `pipeline/fetch.py` downloads them from their owners.

## Acknowledgements

With thanks to the sources the counts were made from:

- MagicData Technology Co., Ltd., *ASR-CShhiDiaCSC: A Chinese Shanghai Dialect Conversational Speech
  Corpus* — https://magichub.com/datasets/shanghai-dialect-conversational-speech-corpus/
- The contributors to the Wu Chinese Wikipedia — https://wuu.wikipedia.org/
- F. L. Hawks Pott, *Lessons in the Shanghai Dialect* (1907), and J. Edkins, *A Grammar of Colloquial
  Chinese, as Exhibited in the Shanghai Dialect* (1868), via Project Gutenberg.
